import React, { useState } from 'react';
import { 
  User, 
  UserRole, 
  RoleAccessRights,
  GradeLevel, 
  StreamName, 
  getStreamsForGrade, 
  getSubjectsForGrade,
  SubjectName,
  GradePassword
} from '../../types';
import { Storage } from '../../utils/storage';
import { EduSmartGadsaLogo } from '../common/EduSmartGadsaLogo';
import { WorkEntryAuditViewer } from '../common/WorkEntryAuditViewer';
import { SanatoriumSection } from '../sanatorium/SanatoriumSection';
import { TransportWorkspace } from '../transport/TransportWorkspace';
import { CoCurricularWorkspace } from '../cocurricular/CoCurricularWorkspace';
import { TimetablePortal } from '../timetable/TimetablePortal';
import { LearnerLunchRegister } from '../meals/LearnerLunchRegister';
import { ReportingHub } from '../reports/ReportingHub';
import { ExtraRolesManager } from './ExtraRolesManager';
import { CMSPostsSectionsHub } from './CMSPostsSectionsHub';
import { DocumentRequestsHub } from './DocumentRequestsHub';
import { SchoolStaffAppraisal, TeacherAppraisalPages } from './TeacherAppraisalPages';
import { BulkUserImportModule } from './BulkUserImportModule';
import { SchoolKpiAnalyticsCharts } from '../analytics/SchoolKpiAnalyticsCharts';
import { 
  Users, 
  Award,
  UserPlus, 
  KeyRound, 
  ShieldCheck, 
  Video, 
  Check, 
  Lock, 
  FileText, 
  BarChart3,
  School,
  GraduationCap,
  AlertCircle,
  RefreshCw,
  HeartPulse,
  Bus,
  Trophy,
  CalendarDays,
  Utensils,
  FileSpreadsheet,
  Edit2,
  Sliders,
  X,
  Save,
  ShieldAlert,
  CheckCircle2,
  Shield,
  SlidersHorizontal,
  Building2,
  ChevronLeft,
  Menu
} from 'lucide-react';
import { IntegratedOperationsHub } from '../operations/IntegratedOperationsHub';

import { useTenant } from '../../context/TenantContext';
import { listSystemRoles } from '../../utils/systemRoles';
import {
  buildUsername,
  nextRegistryNumber,
  registryKindCode,
  rolePassword,
  uniqueUsername,
} from '../../utils/accountCredentials';
import { findSchoolAccountBySchoolId } from '../../utils/schoolAccounts';
import { saveProvisionedAccount } from '../../utils/provisionedAccounts';
import { assignUserToRole, isDirectoryRole, keptProfile } from '../../utils/roleSeatStore';
import { SchoolActionMenu, type AdminActionTab } from './SchoolActionMenu';
import { StudentDirectoryPage } from './StudentDirectoryPage';
import { GradeClassPages } from './GradeClassPages';
import { DepartmentPages } from './DepartmentPages';
import { RoleDirectory } from './RoleDirectory';

interface AdminDashboardProps {
  currentUser: User;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ currentUser }) => {
  const { currentTenant } = useTenant();
  const isSuperAdmin = currentUser.role === 'admin';
  const isHeadTeacher = currentUser.role === 'head_teacher';
  const isDeputyHead = currentUser.role === 'deputy_head';
  const isDean = currentUser.role === 'dean_of_studies';

  // Sub-tabs: Default to overview (Panel 3 School Dashboard)
  const defaultTab = 'overview';
  const [activeTab, setActiveTab] = useState<AdminActionTab>(() => {
    const stored = sessionStorage.getItem('edusmart_school_admin_tab');
    return (stored as AdminActionTab) || defaultTab;
  });
  const openTab = (tab: AdminActionTab) => {
    sessionStorage.setItem('edusmart_school_admin_tab', tab);
    setActiveTab(tab);
  };
  const [menuCollapsed, setMenuCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // User state synced with Storage
  const [allUsers, setAllUsers] = useState<User[]>(() => Storage.getUsers());
  const [rolePermissions, setRolePermissions] = useState<Record<UserRole, RoleAccessRights>>(() => Storage.getRolePermissions());
  
  // Real-time synchronization
  React.useEffect(() => {
    const handleUsersUpdate = () => setAllUsers(Storage.getUsers());
    const handlePermsUpdate = () => setRolePermissions(Storage.getRolePermissions());
    window.addEventListener('users-updated', handleUsersUpdate);
    window.addEventListener('role-permissions-updated', handlePermsUpdate);
    return () => {
      window.removeEventListener('users-updated', handleUsersUpdate);
      window.removeEventListener('role-permissions-updated', handlePermsUpdate);
    };
  }, []);

  React.useEffect(() => {
    const handleNavEvent = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      const tab = customEvent.detail;
      if (tab) {
        if (['overview', 'grades', 'students', 'departments', 'teachers', 'analytics', 'users', 'create_user', 'bulk_import', 'extra_roles', 'cms_hub', 'doc_requests', 'staff_appraisal', 'permissions', 'passwords', 'virtual_rooms', 'work_entry_audit', 'timetable', 'sanatorium', 'lunch_register', 'transport', 'cocurricular', 'oversight', 'reports', 'operations'].includes(tab)) {
          openTab(tab as AdminActionTab);
        } else if (tab === 'logs' || tab === 'audit') {
          setActiveTab('oversight');
        } else if (tab === 'gradebook') {
          setActiveTab('oversight');
        } else if (tab === 'finance' || tab === 'procurement' || tab === 'stores' || tab === 'hr') {
          setActiveTab('operations');
        }
      }
    };
    window.addEventListener('workspace-nav-tab', handleNavEvent);
    return () => window.removeEventListener('workspace-nav-tab', handleNavEvent);
  }, []);

  // Edit User & Assign Role Modal State
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('student');
  const [editGrade, setEditGrade] = useState<GradeLevel>(4);
  const [editStream, setEditStream] = useState<StreamName>('Dove');
  const [editIdNumber, setEditIdNumber] = useState('');
  const [editDepartment, setEditDepartment] = useState('');
  const [editDesignation, setEditDesignation] = useState('');
  const [editCustomPermissions, setEditCustomPermissions] = useState<Partial<RoleAccessRights>>({});
  const [actionToast, setActionToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setActionToast({ message, type });
    setTimeout(() => setActionToast(null), 4000);
  };

  // Create User Form
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<UserRole | ''>('');
  const [systemRoles] = useState(() => listSystemRoles());
  const [newGrade, setNewGrade] = useState<GradeLevel>(4);
  const [newStream, setNewStream] = useState<StreamName>('Dove');
  const [newIdNumber, setNewIdNumber] = useState('');
  const [newDepartment, setNewDepartment] = useState('Sciences & Mathematics');
  const [newSelectedChildId, setNewSelectedChildId] = useState('usr-stu-brian');
  const [newStudentParentName, setNewStudentParentName] = useState('');
  const [newStudentParentPhone, setNewStudentParentPhone] = useState('');
  const [newStudentParentEmail, setNewStudentParentEmail] = useState('');
  const [newStudentParentRel, setNewStudentParentRel] = useState('Parent');
  const [createUserSuccess, setCreateUserSuccess] = useState(false);
  const [createUserError, setCreateUserError] = useState('');

  // Password management
  const [gradePasswords, setGradePasswords] = useState<GradePassword[]>(Storage.getGradePasswords());
  const [editingGrade, setEditingGrade] = useState<GradeLevel | null>(null);
  const [editPassValue, setEditPassValue] = useState('');

  const workLogs = Storage.getWorkEntryLogs();
  const gatePasses = Storage.getGatePasses();
  const virtualClasses = Storage.getVirtualClasses();

  // Open Edit User & Assign Role Modal
  const handleOpenEditUserModal = (user: User) => {
    setEditingUser(user);
    setEditName(user.name);
    setEditEmail(user.email);
    setEditPassword(user.password || '');
    setEditRole(user.role);
    setEditGrade(user.grade || 4);
    setEditStream(user.stream || 'Dove');
    setEditIdNumber(user.admissionNumber || user.tscNumber || '');
    setEditDepartment(user.department || '');
    setEditDesignation(user.designation || '');
    // Load custom permissions or default from current role
    setEditCustomPermissions(user.customPermissions ? { ...user.customPermissions } : {});
  };

  // Save Edited User and Role
  const handleSaveUserRoleAndPermissions = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    if (!editEmail.includes('@')) {
      showToast('Please provide a valid email address.', 'error');
      return;
    }

    const updates: Partial<User> = {
      name: editName.trim(),
      email: editEmail.trim().toLowerCase(),
      password: editPassword.trim(),
      role: editRole,
      designation: editDesignation.trim(),
      grade: ['student', 'class_teacher'].includes(editRole) ? editGrade : undefined,
      stream: ['student', 'class_teacher'].includes(editRole) ? editStream : undefined,
      department: editRole === 'hod' ? editDepartment : undefined,
      admissionNumber: editRole === 'student' ? editIdNumber : undefined,
      tscNumber: ['teacher', 'class_teacher', 'hod', 'senior_teacher', 'dean_of_studies', 'deputy_head', 'librarian', 'head_teacher', 'nurse'].includes(editRole) ? editIdNumber : undefined,
      customPermissions: Object.keys(editCustomPermissions).length > 0 ? editCustomPermissions : undefined
    };

    const previousRole = editingUser.role;
    const updated = Storage.updateUser(editingUser.id, updates);
    if (updated) {
      if (updated.role !== previousRole && isDirectoryRole(updated.role)) {
        const seat = assignUserToRole(currentTenant.id, updated.role, updated, keptProfile(editingUser));
        const started = [...seat.holders].reverse().find((holder) => !holder.endedAt)?.startedAt;
        if (started) Storage.updateUser(updated.id, { roleStartedAt: started, roleReleasedAt: undefined });
      }
      saveProvisionedAccount(Storage.getUsers().find((user) => user.id === updated.id) || updated);
      setAllUsers(Storage.getUsers());
      showToast(`User ${updated.name} successfully updated! Role assigned as ${editRole.replace('_', ' ').toUpperCase()}.`, 'success');
      setEditingUser(null);
    }
  };

  // Toggle user-level custom permission
  const handleToggleUserPermission = (permKey: keyof RoleAccessRights) => {
    if (!editingUser) return;
    const effective = Storage.getUserEffectivePermissions({
      ...editingUser,
      role: editRole,
      customPermissions: editCustomPermissions
    });
    setEditCustomPermissions(prev => ({
      ...prev,
      [permKey]: !effective[permKey]
    }));
  };

  // Reset user-level custom permission to baseline role defaults
  const handleResetUserPermissionsToRole = () => {
    setEditCustomPermissions({});
    showToast('Reset user permissions to default profile for role ' + editRole, 'info');
  };

  // Toggle global role permission policy
  const handleToggleGlobalRolePermission = (role: UserRole, permKey: keyof RoleAccessRights) => {
    // If nurse, restrict to Sanatorium only by system security policy
    if (role === 'nurse' && permKey !== 'canAccessSanatorium') {
      showToast('School Nursing Officer is strictly restricted to School Sanatorium Clinic portal by institutional health privacy policy.', 'error');
      return;
    }
    const currentVal = rolePermissions[role]?.[permKey] ?? false;
    Storage.updateRolePermissions(role, { [permKey]: !currentVal });
    setRolePermissions(Storage.getRolePermissions());
    showToast(`Updated access right [${permKey}] for role [${role.replace('_', ' ')}]`, 'success');
  };

  // Reset all role permissions to factory defaults
  const handleResetAllRolePermissions = () => {
    localStorage.removeItem('edusmart_role_permissions_v1');
    setRolePermissions(Storage.getRolePermissions());
    showToast('All role access permissions have been reset to factory defaults.', 'info');
  };

  // Handle Create User
  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    setCreateUserError('');
    setCreateUserSuccess(false);

    const selectedRole = systemRoles.find((role) => role.slug === newRole);
    if (!newName.trim() || !newEmail.includes('@')) {
      setCreateUserError('Type the full legal name so the username can be created.');
      return;
    }
    if (!selectedRole || !newPassword) {
      setCreateUserError('Choose an account role so the password can be created.');
      return;
    }
    if (selectedRole.numberKind !== 'none' && !newIdNumber.trim()) {
      setCreateUserError('The admission or staff number is still empty.');
      return;
    }

    const existing = Storage.findUserByEmail(newEmail);
    if (existing) {
      setCreateUserError('An account with this email address already exists.');
      return;
    }

    const newUser: User = {
      id: `usr-${newRole}-${Date.now()}`,
      name: newName.trim(),
      email: newEmail.trim().toLowerCase(),
      password: newPassword,
      role: newRole as UserRole,
      schoolId: currentTenant?.id || 'tenant-riara',
      isActive: true,
      grade: newRole === 'student' || newRole === 'class_teacher' ? newGrade : undefined,
      stream: newRole === 'student' || newRole === 'class_teacher' ? newStream : undefined,
      department: newRole === 'hod' ? newDepartment : undefined,
      childrenIds: newRole === 'parent' ? [newSelectedChildId] : undefined,
      admissionNumber: selectedRole.numberKind === 'admission' ? newIdNumber.trim() : undefined,
      staffNumber: selectedRole.numberKind === 'staff' ? newIdNumber.trim() : undefined,
      designation: selectedRole.name,
      assignedSubjects: newRole === 'teacher' ? ['Mathematics', 'Integrated Science'] : undefined
    };

    // If creating a student and parent details are entered, interlink them
    if (newRole === 'student' && newStudentParentName.trim()) {
      const pName = newStudentParentName.trim();
      const pPhone = newStudentParentPhone.trim();
      const pRel = newStudentParentRel.trim() || 'Parent';
      const cleanEmail = newStudentParentEmail.trim().toLowerCase() || `parent.${pName.toLowerCase().replace(/[^a-z0-9]/g, '')}@parents.edusmart.ac.ke`;

      const allExisting = Storage.getUsers();
      const existingParent = allExisting.find(u => 
        u.role === 'parent' && (
          (cleanEmail && u.email.toLowerCase() === cleanEmail) ||
          (pPhone && u.phone && u.phone.replace(/\D/g, '') === pPhone.replace(/\D/g, ''))
        )
      );

      if (existingParent) {
        newUser.parentId = existingParent.id;
        newUser.parentName = existingParent.name;
        newUser.parentPhone = existingParent.phone;
        newUser.parentEmail = existingParent.email;
        newUser.parentRelationship = pRel;
        const currentChildren = new Set(existingParent.childrenIds || []);
        currentChildren.add(newUser.id);
        existingParent.childrenIds = Array.from(currentChildren);
        Storage.addUser(existingParent);
        saveProvisionedAccount(existingParent);
      } else {
        const newParentUser: User = {
          id: `usr-parent-${Date.now()}`,
          name: pName,
          email: cleanEmail,
          password: 'parent2026',
          role: 'parent',
          schoolId: currentTenant?.id || 'tenant-riara',
          isActive: true,
          phone: pPhone || undefined,
          childrenIds: [newUser.id],
          designation: `${pRel} / Guardian`,
        };
        newUser.parentId = newParentUser.id;
        newUser.parentName = newParentUser.name;
        newUser.parentPhone = newParentUser.phone;
        newUser.parentEmail = newParentUser.email;
        newUser.parentRelationship = pRel;
        Storage.addUser(newParentUser);
        saveProvisionedAccount(newParentUser);
      }
    }

    // If creating a parent, bidirectional link to selected child
    if (newRole === 'parent' && newSelectedChildId) {
      const allExisting = Storage.getUsers();
      const childStudent = allExisting.find(u => u.id === newSelectedChildId);
      if (childStudent) {
        childStudent.parentId = newUser.id;
        childStudent.parentName = newUser.name;
        childStudent.parentPhone = newUser.phone;
        childStudent.parentEmail = newUser.email;
        childStudent.parentRelationship = 'Parent';
        Storage.addUser(childStudent);
        saveProvisionedAccount(childStudent);
      }
    }

    Storage.addUser(newUser);
    saveProvisionedAccount(newUser);
    setAllUsers(Storage.getUsers());
    setCreateUserSuccess(true);
    setNewName('');
    setNewEmail('');
    setNewPassword('');
    setNewRole('');
    setNewIdNumber('');
    setNewStudentParentName('');
    setNewStudentParentPhone('');
    setNewStudentParentEmail('');
    setNewStudentParentRel('Parent');
    setTimeout(() => setCreateUserSuccess(false), 3000);
  };

  // Update grade password
  const handleSaveGradePassword = (grade: GradeLevel) => {
    if (!editPassValue.trim()) return;
    Storage.updateGradePassword(grade, editPassValue.trim());
    setGradePasswords(Storage.getGradePasswords());
    setEditingGrade(null);
    setEditPassValue('');
  };

  return (
    <div className="flex w-full items-start">
      <SchoolActionMenu
        activeTab={activeTab}
        onSelect={openTab}
        collapsed={menuCollapsed}
        onToggleCollapsed={() => setMenuCollapsed((open) => !open)}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        userCount={allUsers.length}
        workLogCount={workLogs.length}
      />
      <div className="min-w-0 flex-1 px-4 py-6 space-y-6 sm:px-6 lg:px-8">
      {/* Leadership & Admin Banner */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700"
            aria-label="Open action menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="bg-slate-50 p-2 rounded-2xl border border-slate-200 shadow-2xs shrink-0 hidden sm:flex items-center justify-center">
            <EduSmartGadsaLogo variant="horizontal" size="sm" />
          </div>
          <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white font-bold text-xl flex sm:hidden items-center justify-center shadow-xs shrink-0">
            <School className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              <span>EduSmart Institutional Governance</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700 font-bold uppercase tracking-wider">
                {currentUser.role.replace('_', ' ')}
              </span>
            </div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              {currentUser.name}
            </h1>
            <div className="text-xs text-slate-600 mt-0.5">
              Authoritative management of user accounts, grade passwords, gate exit security logs, and curriculum allocation.
            </div>
          </div>
        </div>

        {/* Quick summary stats */}
        <div className="flex items-center gap-3 text-xs">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-slate-500 text-[10px] uppercase font-bold">Total Accounts</div>
            <div className="text-base font-extrabold font-mono text-slate-900">{allUsers.length}</div>
          </div>
          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
            <div className="text-emerald-800 text-[10px] uppercase font-bold">Active Passes</div>
            <div className="text-base font-extrabold font-mono text-emerald-700">{gatePasses.filter(p => p.status === 'active').length}</div>
          </div>
        </div>
      </div>

      {activeTab === 'grades' && (
        <GradeClassPages
          schoolId={currentTenant.id}
          domain={findSchoolAccountBySchoolId(currentTenant.id)?.domain || currentTenant.domain}
        />
      )}

      {activeTab === 'students' && (
        <StudentDirectoryPage
          schoolId={currentTenant.id}
          domain={findSchoolAccountBySchoolId(currentTenant.id)?.domain || currentTenant.domain}
        />
      )}

      {activeTab === 'departments' && (
        <DepartmentPages schoolId={currentTenant.id} />
      )}

      {activeTab === 'teachers' && (
        <TeacherAppraisalPages
          schoolId={currentTenant.id}
          domain={findSchoolAccountBySchoolId(currentTenant.id)?.domain || currentTenant.domain}
          currentUser={currentUser}
        />
      )}

      {/* ========================================================
          OVERVIEW TAB (MATCHING PANEL 3 IN USER ARCHITECTURAL DIAGRAM)
          Tenant School Dashboard (e.g. Riara School)
          ======================================================== */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* School Hero Branded Banner (Panel 3) */}
          <div className="relative rounded-3xl overflow-hidden bg-slate-900 border border-slate-200/90 shadow-xl">
            {/* Campus Background Photo with Subtle Dark Gradient */}
            <div className="absolute inset-0">
              <img
                src={currentTenant.heroImageUrl || "/gad@edusmart.jpeg"}
                alt={`${currentTenant.name} Campus Grounds`}
                className="w-full h-full object-cover object-center opacity-30"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-blue-950/80" />
            </div>

            <div className="relative p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-center gap-5">
                {/* Crest Logo */}
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white p-2 shadow-xl border-2 border-amber-400/80 flex items-center justify-center shrink-0">
                  {currentTenant.logoUrl ? (
                    <img src={currentTenant.logoUrl} alt={currentTenant.name} className="w-full h-full object-contain" />
                  ) : (
                    <School className="w-10 h-10 text-blue-700" />
                  )}
                </div>

                <div className="text-left space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-black uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2 py-0.5 rounded">
                      {currentTenant.code} · ACTIVE TENANT
                    </span>
                    <span className="text-xs text-slate-400">Term 1, 2026 Academic Session</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black text-white font-serif tracking-tight">
                    {currentTenant.name}
                  </h2>
                  <p className="text-xs sm:text-sm text-amber-300 font-medium">
                    {currentTenant.motto || 'Learn · Grow · Succeed'}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => openTab('grades')}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>Create grade</span>
                </button>
                <button
                  onClick={() => openTab('users')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Users className="w-4 h-4" />
                  <span>Manage Users</span>
                </button>
                <button
                  onClick={() => openTab('reports')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  <span>Academic Dossiers</span>
                </button>
              </div>
            </div>
          </div>

          {/* 4 Stat KPI Cards (Panel 3: Total Students 1,248 | Total Teachers 86 | Classes 42 | Attendance Today 96%) */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-1 text-left">
              <div className="flex items-center justify-between text-slate-500">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Students</span>
                <Users className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-3xl font-black text-slate-900 font-mono">
                {(currentTenant.totalStudents || 1248).toLocaleString()}
              </div>
              <div className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                <span>↑ 4.2% from last term</span>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-1 text-left">
              <div className="flex items-center justify-between text-slate-500">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Teachers</span>
                <Award className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-3xl font-black text-slate-900 font-mono">
                {currentTenant.totalFaculty || 86}
              </div>
              <div className="text-[11px] text-slate-500 font-medium">
                100% TSC & CBA Accredited
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-1 text-left">
              <div className="flex items-center justify-between text-slate-500">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Classes</span>
                <School className="w-4 h-4 text-purple-600" />
              </div>
              <div className="text-3xl font-black text-slate-900 font-mono">
                {currentTenant.totalClasses || 42}
              </div>
              <div className="text-[11px] text-slate-500 font-medium">
                PP1 to Grade 9 Junior Secondary
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-1 text-left">
              <div className="flex items-center justify-between text-slate-500">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Attendance Today</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-3xl font-black text-emerald-700 font-mono">
                {currentTenant.attendanceToday || 96}%
              </div>
              <div className="text-[11px] text-slate-500 font-medium">
                Perimeter GPS & Gate verified
              </div>
            </div>

          </div>

          {/* Institutional KPI Analytics Section (Recharts Engine) */}
          <SchoolKpiAnalyticsCharts
            currentUser={currentUser}
            variant="full"
            defaultSection="all"
            title={`${currentTenant.name} Key Performance Indicators: Attendance Trends & Academic Metrics`}
            subtitle="Real-time Recharts visualization of daily roll call presence, longitudinal CBC competency, and subject means."
          />

          {/* 2-Column Section: Recent Activities (Left) & Upcoming Events (Right) - Matching Panel 3 */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left 7 Cols: Recent Activities */}
            <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-5 text-left">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-base font-black text-slate-900 font-serif">Recent Activities</h3>
                  <p className="text-xs text-slate-500">Live feed of institutional assessments and student updates</p>
                </div>
                <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                  Real-Time
                </span>
              </div>

              <div className="space-y-3.5">
                
                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50/80 border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-slate-900">New assignment posted</div>
                    <div className="text-[11px] text-slate-600">Mathematics – Form 2 / Grade 7 (Linear Equations & Graphs)</div>
                  </div>
                  <span className="text-[10px] font-medium text-slate-400 shrink-0">2 hours ago</span>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50/80 border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-slate-900">Attendance updated</div>
                    <div className="text-[11px] text-slate-600">Form 1A / Grade 7A register submitted by Class Teacher</div>
                  </div>
                  <span className="text-[10px] font-medium text-slate-400 shrink-0">3 hours ago</span>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50/80 border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Users className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-slate-900">Parent message</div>
                    <div className="text-[11px] text-slate-600">From Jane Wanjiru regarding transport drop-off stop change</div>
                  </div>
                  <span className="text-[10px] font-medium text-slate-400 shrink-0">4 hours ago</span>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50/80 border border-slate-200/80">
                  <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
                    <UserPlus className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-slate-900">New student enrolled</div>
                    <div className="text-[11px] text-slate-600">Form 3B / Grade 8B admitted under NEMIS registration clearance</div>
                  </div>
                  <span className="text-[10px] font-medium text-slate-400 shrink-0">5 hours ago</span>
                </div>

              </div>
            </div>

            {/* Right 5 Cols: Upcoming Events */}
            <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-5 text-left">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-base font-black text-slate-900 font-serif">Upcoming Events</h3>
                  <p className="text-xs text-slate-500">Institutional calendar & assembly schedules</p>
                </div>
                <CalendarDays className="w-4 h-4 text-blue-600" />
              </div>

              <div className="space-y-3.5">
                
                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex flex-col items-center justify-center shrink-0 font-bold">
                    <span className="text-sm font-black leading-none">12</span>
                    <span className="text-[9px] uppercase tracking-wider font-mono">APR</span>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">School Assembly</div>
                    <div className="text-[11px] text-slate-500">8:00 AM – 9:00 AM · Main Assembly Quad</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex flex-col items-center justify-center shrink-0 font-bold">
                    <span className="text-sm font-black leading-none">14</span>
                    <span className="text-[9px] uppercase tracking-wider font-mono">APR</span>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Parent-Teacher Meeting</div>
                    <div className="text-[11px] text-slate-500">10:00 AM – 1:00 PM · CBC Consultation Hall</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-12 h-12 rounded-xl bg-purple-600 text-white flex flex-col items-center justify-center shrink-0 font-bold">
                    <span className="text-sm font-black leading-none">18</span>
                    <span className="text-[9px] uppercase tracking-wider font-mono">APR</span>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Mid-Term Exams</div>
                    <div className="text-[11px] text-slate-500">All Day · Formative & Summative CBA Papers</div>
                  </div>
                </div>

              </div>
            </div>

          </div>

        </div>
      )}

      {/* ========================================================
          TAB: ATTENDANCE & ACADEMIC KPI ANALYTICS (RECHARTS ENGINE)
          ======================================================== */}
      {activeTab === 'analytics' && (
        <section className="space-y-6">
          <SchoolKpiAnalyticsCharts
            currentUser={currentUser}
            variant="full"
            defaultSection="all"
            title={`${currentTenant.name} Comprehensive KPI Surveillance Console`}
            subtitle="Real-time Recharts analytics tracking daily roll call presence rates, subject performance aggregates, and MoE CBC competency rubrics."
          />
        </section>
      )}

      {activeTab === 'users' && (
        <RoleDirectory
          schoolId={currentTenant.id}
          users={allUsers}
          onEdit={handleOpenEditUserModal}
          onChanged={(message) => { setAllUsers(Storage.getUsers()); showToast(message, 'success'); }}
        />
      )}


      {/* ========================================================
          TAB 2: CREATE USER ACCOUNT (ADMIN ONLY)
          ======================================================== */}
      {activeTab === 'create_user' && (
        <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="pb-4 border-b border-slate-200">
            <h2 className="text-lg font-bold text-slate-900">
              Create New School User Account
            </h2>
            <p className="text-xs text-slate-500">
              Type the full legal name to preview the username. Choose the role to preview the password and the admission or staff number.
            </p>
          </div>

          {createUserSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>User account successfully created! The user can now log into their assigned workspace.</span>
            </div>
          )}

          {createUserError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <span>{createUserError}</span>
            </div>
          )}

          <form onSubmit={handleCreateUser} className="space-y-4 max-w-2xl">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Full Legal Name
              </label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => {
                  const name = e.target.value;
                  setNewName(name);
                  const domain = findSchoolAccountBySchoolId(currentTenant.id)?.domain || currentTenant.domain || '';
                  const taken = Storage.getUsers().map((user) => user.email).filter(Boolean);
                  setNewEmail(uniqueUsername(buildUsername(name, domain), taken));
                }}
                placeholder="e.g. Mary Wanjiku Kamau"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username
              </label>
              <input
                type="text"
                readOnly
                value={newEmail}
                placeholder="Username appears here as you type the full name"
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-slate-50 font-mono text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Account Role
              </label>
              <select
                required
                value={newRole}
                onChange={(e) => {
                  const slug = e.target.value as UserRole;
                  setNewRole(slug);
                  const role = systemRoles.find((item) => item.slug === slug);
                  if (!role) {
                    setNewPassword('');
                    setNewIdNumber('');
                    return;
                  }
                  setNewPassword(rolePassword(role.passwordPrefix));
                  const code = registryKindCode(role.numberKind);
                  if (!code) {
                    setNewIdNumber('');
                    return;
                  }
                  const year = new Date().getFullYear();
                  const existing = Storage.getUsers()
                    .filter((user) => (user.schoolId || currentTenant.id) === currentTenant.id)
                    .flatMap((user) => [user.admissionNumber, user.staffNumber, user.tscNumber].filter(Boolean) as string[]);
                  setNewIdNumber(nextRegistryNumber(code, year, existing));
                }}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold bg-white"
              >
                <option value="">Choose an account role</option>
                {systemRoles.map((role) => (
                  <option key={role.id} value={role.slug}>{role.name}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password
                </label>
                <input
                  type="text"
                  readOnly
                  value={newPassword}
                  placeholder="Password appears after you choose the role"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-slate-50 font-mono font-bold text-slate-900"
                />
              </div>

              {systemRoles.find((role) => role.slug === newRole)?.numberKind !== 'none' && newRole !== '' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {systemRoles.find((role) => role.slug === newRole)?.numberKind === 'admission' ? 'Admission number' : 'Staff number'}
                  </label>
                  <input
                    type="text"
                    value={newIdNumber}
                    onChange={(e) => setNewIdNumber(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono bg-white"
                  />
                </div>
              )}
            </div>

            {/* If Student or Class Teacher: select exactly 1 grade and 1 stream */}
            {['student', 'class_teacher'].includes(newRole) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Assigned Grade (Strictly 1 Grade)
                  </label>
                  <select
                    value={newGrade}
                    onChange={(e) => {
                      const g = Number(e.target.value) as GradeLevel;
                      setNewGrade(g);
                      setNewStream(getStreamsForGrade(g)[0] as StreamName);
                    }}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold"
                  >
                    {([1, 2, 3, 4, 5, 6, 7, 8, 9] as GradeLevel[]).map(g => (
                      <option key={g} value={g}>Grade {g}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Assigned Stream ({newGrade <= 6 ? '8 Primary Streams' : '7 Junior Streams'})
                  </label>
                  <select
                    value={newStream}
                    onChange={(e) => setNewStream(e.target.value as StreamName)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold"
                  >
                    {getStreamsForGrade(newGrade).map(s => (
                      <option key={s} value={s}>{s} Stream</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {/* If Student: Parent / Guardian Details for automatic profile interlink */}
            {newRole === 'student' && (
              <div className="p-4 bg-indigo-50/60 rounded-xl border border-indigo-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-indigo-950 uppercase tracking-wider">Parent / Guardian Information (Auto-Interlinked)</h4>
                    <p className="text-[11px] text-indigo-700">Enter parent contact to automatically provision and interlink their parent portal account.</p>
                  </div>
                  <span className="text-[10px] bg-indigo-200 text-indigo-900 font-bold px-2 py-0.5 rounded-full">Automatic Link</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Parent Full Name</label>
                    <input
                      type="text"
                      value={newStudentParentName}
                      onChange={(e) => setNewStudentParentName(e.target.value)}
                      placeholder="e.g. Mary Wanjiku"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Parent Phone Number</label>
                    <input
                      type="text"
                      value={newStudentParentPhone}
                      onChange={(e) => setNewStudentParentPhone(e.target.value)}
                      placeholder="+254 712 345 678"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Parent Email (Optional)</label>
                    <input
                      type="email"
                      value={newStudentParentEmail}
                      onChange={(e) => setNewStudentParentEmail(e.target.value)}
                      placeholder="parent@example.com (or auto-assigned)"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Relationship to Learner</label>
                    <select
                      value={newStudentParentRel}
                      onChange={(e) => setNewStudentParentRel(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white font-semibold"
                    >
                      <option value="Parent">Parent</option>
                      <option value="Mother">Mother</option>
                      <option value="Father">Father</option>
                      <option value="Guardian">Legal Guardian</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* If HOD: Department selection */}
            {newRole === 'hod' && (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Department Assigned
                </label>
                <select
                  value={newDepartment}
                  onChange={(e) => setNewDepartment(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold"
                >
                  <option value="Sciences & Mathematics">Sciences & Mathematics</option>
                  <option value="Languages & Linguistics">Languages (English & Kiswahili)</option>
                  <option value="Humanities & Social Studies">Humanities (Social Studies & CRE)</option>
                  <option value="Technical, Applied & Creative Arts">Technical, Applied & Creative Arts</option>
                </select>
              </div>
            )}

            {/* If Parent: Link to child student */}
            {newRole === 'parent' && (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Link to Enrolled Child (Student)
                </label>
                <select
                  value={newSelectedChildId}
                  onChange={(e) => setNewSelectedChildId(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold"
                >
                  {allUsers.filter(u => u.role === 'student').map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} (Grade {s.grade} {s.stream}) - {s.admissionNumber}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
              >
                Create Account & Provision Access
              </button>
            </div>
          </form>
        </section>
      )}

      {/* ========================================================
          TAB: BULK ONBOARDING & ADMISSIONS (TERM OPENING)
          ======================================================== */}
      {activeTab === 'bulk_import' && (
        <BulkUserImportModule 
          currentUser={currentUser} 
          onSuccessNotification={(msg) => showToast(msg, 'success')} 
        />
      )}

      {/* ========================================================
          TAB 3: GRADE PASSWORDS MANAGEMENT
          ======================================================== */}
      {activeTab === 'passwords' && (
        <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Grade-Based Access Passwords (Grades 1 to 9)
            </h2>
            <p className="text-xs text-slate-500">
              Admin can update or reset passwords for each grade portal.
            </p>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden max-w-2xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-4">Grade Level</th>
                  <th className="py-2.5 px-4">Category</th>
                  <th className="py-2.5 px-4">Current Password</th>
                  <th className="py-2.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono">
                {gradePasswords.map((gp) => (
                  <tr key={gp.grade} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-sans font-bold text-slate-900">Grade {gp.grade}</td>
                    <td className="py-3 px-4 font-sans text-slate-600">
                      {gp.grade <= 6 ? 'Primary (8 Streams)' : 'Junior School (7 Streams)'}
                    </td>
                    <td className="py-3 px-4">
                      {editingGrade === gp.grade ? (
                        <input
                          type="text"
                          value={editPassValue}
                          onChange={(e) => setEditPassValue(e.target.value)}
                          className="px-2 py-1 text-xs border border-emerald-500 rounded font-mono font-bold"
                        />
                      ) : (
                        <span className="font-bold text-emerald-700">{gp.password}</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-sans">
                      {editingGrade === gp.grade ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleSaveGradePassword(gp.grade)}
                            className="px-2.5 py-1 bg-emerald-600 text-white rounded text-xs font-bold"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingGrade(null)}
                            className="px-2 py-1 bg-slate-200 text-slate-700 rounded text-xs"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            setEditingGrade(gp.grade);
                            setEditPassValue(gp.password);
                          }}
                          className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold"
                        >
                          Change
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* ========================================================
          TAB 4: GOOGLE MEET VIRTUAL ROOM LINKS
          ======================================================== */}
      {activeTab === 'virtual_rooms' && (
        <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Virtual Classroom Google Meet Links
            </h2>
            <p className="text-xs text-slate-500">
              Configure active Google Meet meeting codes and URLs for each grade and stream.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {virtualClasses.map((vc) => (
              <div key={vc.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    Grade {vc.grade} {vc.stream ? `(${vc.stream})` : ''} · {vc.subject}
                  </span>
                  <span className="text-[10px] font-mono uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">
                    Connected
                  </span>
                </div>
                <div className="text-xs text-slate-600 font-mono break-all bg-white p-2.5 rounded border border-slate-200">
                  {vc.googleMeetLink}
                </div>
                <div className="text-[11px] text-slate-500">Host: {vc.teacherName}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ========================================================
          TAB: WORK ENTRY SIGN-IN AUDIT (READ-ONLY)
          ======================================================== */}
      {activeTab === 'work_entry_audit' && (
        <WorkEntryAuditViewer 
          currentUser={currentUser} 
          title="System Administrator Work Entry Sign-In Register"
          subtitle="System-wide institutional audit ledger: Real-time clock-in logs, GPS stamps, staff credentials, and verified biometric photos. Strictly non-editable."
        />
      )}

      {/* ========================================================
          TAB: MASTER TIMETABLE & BELL SCHEDULE
          ======================================================== */}
      {activeTab === 'timetable' && (
        <TimetablePortal 
          currentUser={currentUser} 
        />
      )}

      {/* ========================================================
          TAB: SYSTEM SANATORIUM & CLINIC LOGS
          ======================================================== */}
      {activeTab === 'sanatorium' && (
        <SanatoriumSection
          currentUser={currentUser}
          canRecord={false}
          title="System Administration Sanatorium & Medical Audit"
          subtitle="System-wide clinic attendance records, nurse in-charge notes, vital signs, and institutional recommendations. Print/Export PDF dossiers. (Read-Only Audit Mode)"
        />
      )}

      {/* ========================================================
          TAB: SYSTEM LEARNER LUNCH REGISTER & DINING AUDIT
          ======================================================== */}
      {activeTab === 'lunch_register' && (
        <LearnerLunchRegister
          currentUser={currentUser}
          viewMode="executive"
          title="System Administration Learner Lunch Register & Dining Audit"
          subtitle="System-wide dining audit: Student attendance records, meal type statistics, and class teacher register verification across all 9 grades and streams."
        />
      )}

      {/* ========================================================
          TAB: SCHOOL TRANSPORT & FLEET TRACKING SYSTEM
          ======================================================== */}
      {activeTab === 'transport' && (
        <TransportWorkspace currentUser={currentUser} isEmbedded={true} readOnly={true} />
      )}

      {/* ========================================================
          TAB: CO-CURRICULAR & TALENT SURVEILLANCE
          ======================================================== */}
      {activeTab === 'cocurricular' && (
        <CoCurricularWorkspace currentUser={currentUser} isEmbedded={true} readOnly={true} />
      )}

      {/* ========================================================
          TAB 5: EXECUTIVE OVERSIGHT & LOGS
          ======================================================== */}
      {activeTab === 'oversight' && (
        <section className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="text-[10px] uppercase font-bold text-slate-500">Total Work Entries Today</div>
              <div className="text-2xl font-extrabold font-mono text-slate-900 mt-1">{workLogs.length}</div>
              <div className="text-xs text-slate-600 mt-0.5">Staff lesson logs submitted</div>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="text-[10px] uppercase font-bold text-slate-500">Security Gate Passes</div>
              <div className="text-2xl font-extrabold font-mono text-slate-900 mt-1">{gatePasses.length}</div>
              <div className="text-xs text-slate-600 mt-0.5">Approved student pass outs</div>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="text-[10px] uppercase font-bold text-slate-500">Curriculum Syllabus Coverage</div>
              <div className="text-2xl font-extrabold font-mono text-emerald-700 mt-1">91.4%</div>
              <div className="text-xs text-emerald-800 mt-0.5">Grade 1 to 9 combined</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Recent Teacher Work Entry Ledger (All Staff)
            </h3>
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Teacher</th>
                    <th className="py-2.5 px-3">Grade & Stream</th>
                    <th className="py-2.5 px-3">Subject</th>
                    <th className="py-2.5 px-3">Topic</th>
                    <th className="py-2.5 px-3 text-center">Learners</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {workLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-mono text-slate-500">{log.date}</td>
                      <td className="py-2 px-3 font-bold text-slate-900">{log.teacherName}</td>
                      <td className="py-2 px-3 text-slate-600">Grade {log.grade} ({log.stream})</td>
                      <td className="py-2 px-3 text-emerald-700 font-semibold">{log.subject}</td>
                      <td className="py-2 px-3 text-slate-700">{log.topicTaught}</td>
                      <td className="py-2 px-3 text-center font-mono font-bold text-slate-900">{log.learnersPresent}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Campus Security Gate Exit Passes (Audit Ledger)
            </h3>
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Pass Code</th>
                    <th className="py-2.5 px-3">Student Name</th>
                    <th className="py-2.5 px-3">Grade & Stream</th>
                    <th className="py-2.5 px-3">Departure / Return</th>
                    <th className="py-2.5 px-3">Guardian</th>
                    <th className="py-2.5 px-3">Authorizing Teacher</th>
                    <th className="py-2.5 px-3 text-center">Status Tracking</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {gatePasses.map((gp) => (
                    <tr key={gp.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-mono font-bold text-slate-900">{gp.gatePassCode}</td>
                      <td className="py-2 px-3 font-bold text-slate-900">{gp.studentName}</td>
                      <td className="py-2 px-3 text-slate-600">Grade {gp.grade} ({gp.stream})</td>
                      <td className="py-2 px-3 font-mono text-[11px]">
                        <div>Dep: {gp.departureTime}</div>
                        <div className="text-slate-500">Exp: {gp.expectedReturnTime || 'Released'}</div>
                      </td>
                      <td className="py-2 px-3 text-slate-700">
                        <div>{gp.guardianName}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{gp.guardianPhone}</div>
                      </td>
                      <td className="py-2 px-3 text-slate-600">{gp.teacherName}</td>
                      <td className="py-2 px-3 text-center">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono uppercase ${
                            gp.status === 'active'
                              ? 'bg-amber-100 text-amber-800'
                              : gp.status === 'departed'
                              ? 'bg-purple-100 text-purple-800'
                              : gp.status === 'returned'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {gp.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      {/* ========================================================
          TAB: ROLE PERMISSIONS MATRIX & ACCESS CONTROL (ADMIN ONLY)
          ======================================================== */}
      {activeTab === 'permissions' && (
        <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider mb-1">
                <Shield className="w-4 h-4 text-indigo-600" />
                <span>Executive Security & Governance Policy</span>
              </div>
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                Role Permissions Matrix & Access Control Center
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Main Administrator has authoritative control to assign roles, expand capabilities, or limit access rights. Changes apply immediately school-wide.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetAllRolePermissions}
                className="px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-rose-700 bg-slate-100 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                title="Reset all role policies to institutional defaults"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset to Factory Defaults</span>
              </button>
            </div>
          </div>

          {/* Access Policy Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-1.5">
              <div className="flex items-center gap-2 text-indigo-950 font-bold text-xs uppercase">
                <span className="p-1 bg-indigo-200 rounded">👑</span>
                <span>Main Administrator Rights</span>
              </div>
              <p className="text-xs text-indigo-900 leading-relaxed">
                Full authority to create, edit, and assign roles across all 15 institutional tiers, and granularly limit or expand access rights per user or per role.
              </p>
            </div>

            <div className="p-4 bg-rose-50/70 border border-rose-200 rounded-xl space-y-1.5">
              <div className="flex items-center gap-2 text-rose-950 font-bold text-xs uppercase">
                <span className="p-1 bg-rose-200 rounded">🏥</span>
                <span>Nurse Sanatorium Scoping</span>
              </div>
              <p className="text-xs text-rose-900 leading-relaxed">
                School Nursing Officer accounts are strictly restricted to the School Sanatorium Clinic portal for student healthcare, sick bay triage, and clinic attendance.
              </p>
            </div>

            <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-xl space-y-1.5">
              <div className="flex items-center gap-2 text-blue-950 font-bold text-xs uppercase">
                <span className="p-1 bg-blue-200 rounded">📢</span>
                <span>Deputy & Dean Rights</span>
              </div>
              <p className="text-xs text-blue-900 leading-relaxed">
                Deputy Head Teacher & Dean of Studies hold authoritative rights to edit teacher remarks, modify qualitative write-ups, and republish official student reports.
              </p>
            </div>
          </div>

          {/* Role Access Matrix Table */}
          <div className="border border-slate-200 rounded-xl overflow-x-auto">
            <table className="w-full text-left text-xs min-w-[900px]">
              <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-3 w-48">Institutional Role</th>
                  <th className="py-3 px-2 text-center" title="Access School Sanatorium Portal">🏥 Sanatorium</th>
                  <th className="py-3 px-2 text-center" title="View Academic Reports & Grading">📊 Reports</th>
                  <th className="py-3 px-2 text-center" title="Edit Narrative & Comment Write-Ups">✏️ Edit Comments</th>
                  <th className="py-3 px-2 text-center" title="Republish Official Student Reports">📢 Republish</th>
                  <th className="py-3 px-2 text-center" title="Manage Users & Assign Roles">👑 Role Admin</th>
                  <th className="py-3 px-2 text-center" title="Curriculum Timetable & Bell Schedule">📅 Timetable</th>
                  <th className="py-3 px-2 text-center" title="Gate Exit Security Passes">🚪 Gate Pass</th>
                  <th className="py-3 px-2 text-center" title="Library Management Portal">📚 Library</th>
                  <th className="py-3 px-2 text-center" title="School Transport Fleet">🚌 Transport</th>
                  <th className="py-3 px-2 text-center" title="Sports & Co-Curricular">🏆 Sports</th>
                  <th className="py-3 px-2 text-center" title="Learner Lunch Register">🍱 Meals</th>
                  <th className="py-3 px-2 text-center" title="Virtual Classroom Google Meet">🎥 Meet</th>
                  <th className="py-3 px-2 text-center" title="Student Discipline & Pastoral">⚖️ Discipline</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {(Object.keys(rolePermissions) as UserRole[]).map((role) => {
                  const perms = rolePermissions[role];
                  const isNurse = role === 'nurse';
                  const isLeadership = ['admin', 'head_teacher', 'deputy_head', 'dean_of_studies'].includes(role);

                  return (
                    <tr key={role} className={`hover:bg-slate-50 transition-colors ${
                      isNurse ? 'bg-rose-50/30' : isLeadership ? 'bg-blue-50/20' : ''
                    }`}>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-900 capitalize">
                          {role.replace('_', ' ')}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {isNurse ? 'Healthcare Medical Bay' : 
                           role === 'deputy_head' ? 'Operations & Reports Moderation' :
                           role === 'dean_of_studies' ? 'Academics & Reports Moderation' :
                           role === 'admin' ? 'Master System Controller' : 'Standard Faculty'}
                        </div>
                      </td>

                      {/* Sanatorium */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          checked={perms.canAccessSanatorium}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessSanatorium')}
                          className="w-4 h-4 text-rose-600 rounded border-slate-300 focus:ring-rose-500 cursor-pointer"
                        />
                      </td>

                      {/* Academic Reports */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canAccessAcademicReports}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessAcademicReports')}
                          className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Edit Comment Write-Ups */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canEditCommentWriteUps}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canEditCommentWriteUps')}
                          className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Republish Reports */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canRepublishReports}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canRepublishReports')}
                          className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Role Admin */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={role !== 'admin' && role !== 'head_teacher'}
                          checked={perms.canManageUsersAndRoles}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canManageUsersAndRoles')}
                          className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Timetable */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canAccessTimetable}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessTimetable')}
                          className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Gate Passes */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canAccessGatePasses}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessGatePasses')}
                          className="w-4 h-4 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Library */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canAccessLibrary}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessLibrary')}
                          className="w-4 h-4 text-purple-600 rounded border-slate-300 focus:ring-purple-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Transport */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canAccessTransport}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessTransport')}
                          className="w-4 h-4 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* CoCurricular */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canAccessCoCurricular}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessCoCurricular')}
                          className="w-4 h-4 text-violet-600 rounded border-slate-300 focus:ring-violet-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Lunch Register */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canAccessLunchRegister}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessLunchRegister')}
                          className="w-4 h-4 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Virtual Rooms */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canAccessVirtualRooms}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canAccessVirtualRooms')}
                          className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>

                      {/* Discipline */}
                      <td className="py-2.5 px-2 text-center">
                        <input
                          type="checkbox"
                          disabled={isNurse}
                          checked={perms.canManageDiscipline}
                          onChange={() => handleToggleGlobalRolePermission(role, 'canManageDiscipline')}
                          className="w-4 h-4 text-rose-600 rounded border-slate-300 focus:ring-rose-500 cursor-pointer disabled:opacity-30"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* ========================================================
          TAB: EXTRA ROLES & DELEGATIONS (5 ROLES ASSIGNED BY ADMIN)
          ======================================================== */}
      {activeTab === 'extra_roles' && (
        <ExtraRolesManager 
          currentUser={currentUser} 
          onNavigateToDocs={() => openTab('doc_requests')}
          onNavigateToCMS={() => openTab('cms_hub')}
        />
      )}

      {/* ========================================================
          TAB: CMS POSTS, CATEGORIES & SECTIONS HUB
          ======================================================== */}
      {activeTab === 'cms_hub' && (
        <CMSPostsSectionsHub currentUser={currentUser} />
      )}

      {/* ========================================================
          TAB: DOCUMENT REQUESTS & SUBMISSIONS HUB
          ======================================================== */}
      {activeTab === 'doc_requests' && (
        <DocumentRequestsHub currentUser={currentUser} />
      )}

      {/* ========================================================
          TAB: TEACHER & STAFF PERFORMANCE APPRAISAL (TSC TPAD)
          ======================================================== */}
      {activeTab === 'staff_appraisal' && (
        <SchoolStaffAppraisal currentUser={currentUser} />
      )}

      {/* ========================================================
          TAB: INTEGRATED OPERATIONS (FINANCE, PROCUREMENT, STORES, HR/PAYROLL & ARCHITECTURE)
          ======================================================== */}
      {activeTab === 'operations' && (
        <IntegratedOperationsHub currentUser={currentUser} />
      )}

      {/* ========================================================
          MODAL: EDIT USER ACCOUNT & ASSIGN ROLE & ACCESS RIGHTS
          ======================================================== */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-xs">
                  <Edit2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Edit User & Assign Institutional Role
                  </h3>
                  <div className="text-xs text-slate-500 font-mono">
                    Account: {editingUser.email} (ID: {editingUser.id})
                  </div>
                </div>
              </div>
              <button
                onClick={() => setEditingUser(null)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleSaveUserRoleAndPermissions} className="p-6 overflow-y-auto flex-1 space-y-6">
              {/* Basic Details */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <span>1. User Identity & Authentication</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      required
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Email Username</label>
                    <input
                      type="email"
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                      required
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
                    <input
                      type="text"
                      value={editPassword}
                      onChange={(e) => setEditPassword(e.target.value)}
                      required
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Designation / Title</label>
                    <input
                      type="text"
                      value={editDesignation}
                      onChange={(e) => setEditDesignation(e.target.value)}
                      placeholder="e.g. Senior Nursing Officer In-Charge, Dean of Studies"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Admission / TSC No.</label>
                    <input
                      type="text"
                      value={editIdNumber}
                      onChange={(e) => setEditIdNumber(e.target.value)}
                      placeholder="e.g. NCK/RN-58921, TSC/12345/ED"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                    />
                  </div>

                  {editRole === 'hod' && (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Department</label>
                      <select
                        value={editDepartment}
                        onChange={(e) => setEditDepartment(e.target.value)}
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-medium"
                      >
                        <option value="Sciences & Mathematics">Sciences & Mathematics</option>
                        <option value="Languages & Humanities">Languages & Humanities</option>
                        <option value="Creative Arts & Applied Technical">Creative Arts & Applied Technical</option>
                      </select>
                    </div>
                  )}

                  {['student', 'class_teacher'].includes(editRole) && (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Grade</label>
                        <select
                          value={editGrade}
                          onChange={(e) => setEditGrade(Number(e.target.value) as GradeLevel)}
                          className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-medium"
                        >
                          {[1,2,3,4,5,6,7,8,9].map(g => (
                            <option key={g} value={g}>Grade {g}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Stream</label>
                        <select
                          value={editStream}
                          onChange={(e) => setEditStream(e.target.value as StreamName)}
                          className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-medium"
                        >
                          {getStreamsForGrade(editGrade).map(s => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Role Assignment */}
              <div className="space-y-3 pt-4 border-t border-slate-200">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center justify-between">
                  <span>2. Assign Institutional Role (Authoritative Admin Control)</span>
                  <span className="text-[10px] text-indigo-700 font-mono">15 Standard School Roles</span>
                </h4>

                <div className="p-3 bg-indigo-50/50 rounded-xl border border-indigo-200 space-y-2">
                  <select
                    value={editRole}
                    onChange={(e) => setEditRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 text-xs font-bold border border-indigo-300 rounded-lg bg-white text-indigo-950 focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="admin">System Administrator (Full Control over All Systems & Roles)</option>
                    <option value="head_teacher">Head Teacher / Principal (School-Wide Management)</option>
                    <option value="deputy_head">Deputy Head Teacher (Operations, Discipline & Full Report Moderation)</option>
                    <option value="dean_of_studies">Dean of Studies (Academics, Curriculum & Full Report Moderation)</option>
                    <option value="curriculum_coordinator">Curriculum Coordinator (Executive Leadership: CBC Curriculum, CBA & Syllabi)</option>
                    <option value="senior_teacher">Senior Teacher (Supervision & Mentorship)</option>
                    <option value="hod">Head of Department (Curriculum Moderation)</option>
                    <option value="class_teacher">Class Teacher (Stream & Learner Dossiers)</option>
                    <option value="teacher">Subject Teacher (Instruction & Grading)</option>
                    <option value="nurse">School Sanatorium Nurse (Strictly Sanatorium Portal Only)</option>
                    <option value="school_admin_staff">School Admin Staff (Front Office & Gate Passes)</option>
                    <option value="librarian">School Librarian (Library Collections & Circulation)</option>
                    <option value="transport_team">Transport Team (Fleet, Routes & Bus Chaperones)</option>
                    <option value="cocurricular_team">Co-Curricular Team (Sports, Games & Club Patrons)</option>
                    <option value="parent">Parent / Guardian (Children Records)</option>
                    <option value="student">Learner / Student (Academic Materials & Tests)</option>
                  </select>

                  {/* Context notice based on chosen role */}
                  {editRole === 'nurse' && (
                    <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-900 flex items-center gap-2">
                      <span className="text-sm">🏥</span>
                      <span>
                        <strong>Sanatorium Scoping Enforcement:</strong> When assigned the Nurse role, this user will ONLY have access to the School Sanatorium Clinic portal. All other modules are strictly locked.
                      </span>
                    </div>
                  )}

                  {(editRole === 'deputy_head' || editRole === 'dean_of_studies') && (
                    <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-900 flex items-center gap-2">
                      <span className="text-sm">⭐</span>
                      <span>
                        <strong>Executive Moderation Rights:</strong> As {editRole === 'deputy_head' ? 'Deputy Head' : 'Dean of Studies'}, this user has full authoritative rights to edit teacher remarks, revise qualitative write-ups, and republish official student reports.
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Granular Access Rights Overrides (Limit or Expand) */}
              <div className="space-y-3 pt-4 border-t border-slate-200">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                    <span>3. Granular Access Rights (Limit or Expand for this User)</span>
                  </h4>
                  <button
                    type="button"
                    onClick={handleResetUserPermissionsToRole}
                    className="text-[11px] text-indigo-700 hover:text-indigo-900 font-bold underline cursor-pointer"
                  >
                    Reset to Role Defaults
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {([
                    { key: 'canAccessSanatorium', label: 'Sanatorium Clinic Portal', icon: '🏥' },
                    { key: 'canAccessAcademicReports', label: 'Academic Reports & Grading', icon: '📊' },
                    { key: 'canEditCommentWriteUps', label: 'Edit Comment-Based Write-Ups', icon: '✏️' },
                    { key: 'canRepublishReports', label: 'Republish Reports & Write-Ups', icon: '📢' },
                    { key: 'canManageUsersAndRoles', label: 'User & Role Administration', icon: '👑' },
                    { key: 'canAccessAdminSettings', label: 'System Admin Governance', icon: '⚙️' },
                    { key: 'canAccessFinancials', label: 'Financials & Event Ticketing', icon: '💳' },
                    { key: 'canAccessTimetable', label: 'Curriculum Timetable & Bell', icon: '📅' },
                    { key: 'canAccessGatePasses', label: 'Gate Exit Security Passes', icon: '🚪' },
                    { key: 'canAccessLibrary', label: 'Library Management System', icon: '📚' },
                    { key: 'canAccessTransport', label: 'School Transport & Fleet', icon: '🚌' },
                    { key: 'canAccessCoCurricular', label: 'Sports & Co-Curricular', icon: '🏆' },
                    { key: 'canAccessLunchRegister', label: 'Learner Lunch Register', icon: '🍱' },
                    { key: 'canAccessVirtualRooms', label: 'Virtual Classrooms (Meet)', icon: '🎥' },
                    { key: 'canManageDiscipline', label: 'Student Discipline & Pastoral', icon: '⚖️' },
                    { key: 'canRequestDocumentSubmissions', label: '1. Request Document Submissions', icon: '📑' },
                    { key: 'canEditPostsBySpecificUsers', label: '2. Edit Posts by Specific Users', icon: '📝' },
                    { key: 'canAddCategoriesToPosts', label: '3. Add Categories Under Posts', icon: '🏷️' },
                    { key: 'hasDoubleAccessRights', label: '4. Double Access Rights (Specific Teachers)', icon: '⚡' },
                    { key: 'canManageAllPostsCategoriesSections', label: '5. Manage Posts, Categories, Sections', icon: '🗂️' },
                  ] as const).map(({ key, label, icon }) => {
                    const effective = Storage.getUserEffectivePermissions({
                      ...editingUser,
                      role: editRole,
                      customPermissions: editCustomPermissions
                    });
                    const isChecked = effective[key];

                    return (
                      <label
                        key={key}
                        className={`flex items-center justify-between p-2.5 rounded-lg border transition-all cursor-pointer ${
                          isChecked 
                            ? 'bg-indigo-50/50 border-indigo-200 text-indigo-950 font-bold' 
                            : 'bg-slate-50 border-slate-200 text-slate-500'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span>{icon}</span>
                          <span className="text-[11px]">{label}</span>
                        </div>
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleUserPermission(key)}
                          className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                        />
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3 sticky bottom-0 bg-white py-2">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-700 hover:bg-indigo-800 rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save User & Apply Permissions</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};
